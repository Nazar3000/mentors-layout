<a name="1.2.1"></a>
### 1.2.1 (2015-03-23)


<a name="1.2.0"></a>
## 1.2.0 (2015-03-23)

#### Features

* add animation duration option ([e1ef7983](https://github.com/craigmdennis/animatecss/commit/e1ef7983c25fec49254611ca4e19a88e5f4b1422))


<a name="1.1.5"></a>
### 1.1.5 (2014-05-27)


<a name="1.1.4"></a>
### 1.1.4-0 (2014-05-27)


<a name="1.1.3-1"></a>
### 1.1.3-1 (2014-05-21)


<a name="1.1.3-0"></a>
### 1.1.3-0 (2014-05-21)


#### Bug Fixes

* stop grunt-bump from trying to bump the CHANGELOG.md ([d06d4126](https://github.com/craigmdennis/animateCSS/commit/d06d4126731efbb8b01f8926d22a9c86bc337757))


<a name="1.1.2-2"></a>
### 1.1.2-2 (2014-05-21)

#### Bug Fixes

* Remove private flag to allow Bower registration


<a name="1.1.2-2"></a>
### 1.1.2-2 (2014-05-21)


<a name="1.1.2-1"></a>
### 1.1.2-1 (2014-05-21)


<a name="1.1.2"></a>
### 1.1.2 (2014-05-21)


<a name="1.1.0"></a>
### 1.1.0 (2014-05-21)


#### Features

* add the ability to use  animation loops ([b477632b](https://github.com/craigmdennis/animatecss/commit/b477632bc87f6d96d7ed2fd0ced0aec296c35952))


#### Breaking Changes

* Delay can no longer be specified in the plugin shorthand ([89e7da1a](https://github.com/craigmdennis/animatecss/commit/89e7da1af66ba58c0078b426353b281b227c6844))

Before:

`$('#your-id').animateCSS('fadeIn', 2000);`

After:

`$('#your-id').animateCSS('fadeIn', {delay:2000});`


<a name="1.0.6"></a>
### 1.0.6 (2013-10-30)


<a name="1.0.5"></a>
### 1.0.5 (2013-10-20)


<a name="1.0.4"></a>
### 1.0.4 (2013-01-18)


<a name="1.0.3"></a>
### 1.0.3 (2013-10-20)


<a name="1.0.2"></a>
### 1.0.2 (2013-10-20)


<a name="1.0.1"></a>
### 1.0.1 (2013-10-17)


<a name="1.0.0"></a>
### 1.0.0 (2012-11-26)
